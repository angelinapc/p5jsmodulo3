let cor; //criando a variável cor
let circuloX; //horizontal //criando a variável "circuloX"
let ciculoY; //vertical //criando a variável "circuloY"

function setup() {
  
  createCanvas(400, 400); //criando o cenário //width(largura) x height(altura)
  background ("white"); //cor do cenário
  cor = color(random(0, 255), random(0, 255), random(0, 55)); //variável "cor", cores aleatórias
  circuloX = [0, 0, 0]; //valor da variável
  circuloY = [random(height), random(height), random(height)]; //valor da variável


}

function draw() { //função de desenhar
  
  fill(cor); //cor do círculo
  
  for(let contador in circuloX) { //contar os elementos
  console.log(contador);
  circle(circuloX [contador], circuloY [contador], 50) //posição e tamanho do círculo
  circuloX[contador] += random(0, 3) //andar valor aleatório entre 0 e 3 na horizntal
  circuloY[contador] += random(-3, 3) //andar valor aleatório entre -3 e 3 na vertical
    
  if(circuloX[contador] >= width) {
   circuloX[contador] = 0;
    circuloY[contador] = random(height);
//quando o círculo chegar na "borda" volta ao "início"
    }
  }
  
    
  if(mouseIsPressed){ //quando o mouse for presionado a cor muda
  cor = color(random(0, 255), random(0, 255), random(0, 55), random(0, 100)); //variável "cor", cores aleatórias
  }
}